# Security Requirements

| Area | Control |
|---|---|
| Passwords | Argon2id/bcrypt; remove all default/hard-coded passwords (`1234`) |
| AuthZ | Server-side permission per endpoint + service; default deny |
| SQL | PDO prepared statements only; explicit column lists; no string-built SQL; no dynamic sort columns except whitelist |
| Input/Output | Validate every request; whitelist resource serializers (never `SELECT *` to client); frontend must stop `innerHTML` with untrusted data (HTML builds rows by string concat — XSS risk; escaping function `E()` exists but is not universal) |
| CSRF | Required if cookie sessions; double-submit or Laravel token |
| CORS | Allow-list the exact frontend origin; no `*` with credentials |
| Rate limiting | Login, password reset, receipts/post endpoints (abuse) |
| Secrets | `.env` on server only, `chmod 600`, never committed; rotate on staff change |
| DB least privilege | App user: SELECT/INSERT/UPDATE (and DELETE only where a verified need exists) on the app schema; **no DDL**; separate read-only user for reports/`schema-verify`; audit table INSERT/SELECT only |
| Audit | Append-only (no UPDATE/DELETE grants) with user, time, IP, entity, before/after, reason |
| Logging | Structured JSON; redact password/token/Authorization; request_id |
| Errors | Generic 500 in production (`APP_DEBUG=false`) |
| Transport | HTTPS only, HSTS, secure cookies, TLS via Let's Encrypt |
| Headers | `X-Content-Type-Options`, `Referrer-Policy`, CSP for any served HTML |
| Concurrency | Row locks + unique constraints; idempotency keys |
| Uploads | None identified; if logo/attachments added: type/size whitelist, outside web root, random names |
| Backups | Daily DB dump encrypted off-box; restore drill monthly |
| Dependencies | `composer audit` in CI; lock file committed |
Threats considered: credential stuffing, privilege escalation via client role, double-submit duplicate posting, race on last unit of stock, IDOR on `/customers/{id}`, XSS via stored names/notes, leakage of markup data (D6).
