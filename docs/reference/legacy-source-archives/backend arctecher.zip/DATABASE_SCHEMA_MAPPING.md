# Database Schema Mapping

## STATUS: **BLOCKED — approved schema not found.**
No SQL dump, migration, ERD, DBML, or DB documentation was present in the workspace. A full filesystem search found no relevant `.sql/.dbml/.php/composer.json`. **No table or column below is verified, and none has been invented.**

## 1. What is needed to unblock (exact list)
1. DDL dump (`mysqldump --no-data`) of the approved database, including engine, charset/collation, indexes, FKs, CHECKs, triggers, views.
2. Column types for every money/quantity column (precision/scale) — decides rounding feasibility.
3. Whether the schema contains: user/role/permission tables, token/session storage, audit table, idempotency storage, document-number sequences, stock-movement ledger, journal tables.
4. MySQL/MariaDB version.
5. Any DB documentation / ERD.

## 2. Capability checklist (what the verified screens require the schema to support)
Source = real HTML behavior. "Present in schema?" must be filled after the dump arrives.

| # | Capability needed | Evidence in HTML | Present in schema? |
|---|---|---|---|
| C1 | Users with hashed passwords, active flag, role | Fake login, `ps-role`, `USERS=['كراس','أبنوب','السائق']` | ? |
| C2 | Roles/permissions (3 levels seen: موظف/محاسب/مدير) | `ALLOW` map | ? |
| C3 | Customers: name, phone, address, credit/balance | `customers`, `c.balanceNum`, `c.phone` | ? |
| C4 | Products: SKU, name, category, price, stock, min stock | `INV_CATALOG`, `DB.products` | ? |
| C5 | Warehouses / locations (main, sub, car, damaged) | `LOCS`, `DMG`, warehouses screen | ? |
| C6 | Stock movement history with type (in/out/ret/transfer/adjust) | `addMovement(...)`, `TRF`, `ps-cmov` | ? |
| C7 | Sales documents + lines (sale/return), issuer, driver, due date, paid | `DB.invoices` shape | ? |
| C8 | Receipts/collections and allocation to invoices | collections screen | ? |
| C9 | Treasuries (main cash, banks) + movements | `DB.cashiers` (main, nbank, rajhi) | ? |
| C10 | Expenses / transfers / financial adjustments | `ps-expenses`, `faSeq` | ? |
| C11 | Containers, cost lines, stages (شراء، شحن، وصول الميناء، جمارك، استلام), receiving | `STG`, container screens | ? |
| C12 | Settings (companies, WhatsApp numbers, history) | `ST` | ? |
| C13 | Audit log | `auditLog` local (per blueprint) | ? |
| C14 | Document number generation (`purchaseSeq`, invoice `no`) | `DB.purchaseSeq` | ? |
| C15 | Idempotency / duplicate protection | none today | ? |
| C16 | Journal entries / chart of accounts | blueprint only; generated at render time | ? |
| C17 | Price markups (D6) | blueprint only | ? |
| C18 | Suppliers/partners/installments | blueprint only (D7/D9) | ? |

## 3. Mapping template (to be completed after verification)
| Verified table.column | PK/FK/constraint | Repository method | Service | API field | Notes |
|---|---|---|---|---|---|
| — | — | — | — | — | Awaiting schema |

## 4. Rules (unchanged)
No renaming/adding/dropping of tables or columns, no type/index/constraint changes, no migrations, no generated replacement DB. If a capability above has no schema support, it is recorded as a **Schema Change Request** in `BACKEND_DECISIONS_AND_GAPS.md` (reason, impact, migration proposal, explicit approval) and the dependent endpoints stay disabled.

## 5. Blueprint tables are NOT verified
The blueprint's `sales_documents`, `stock_movements`, `receipts`, `receipt_allocations`, `treasury_entries`, `idempotency_keys`, `price_markups`, … (UUID PKs, `NUMERIC`) are **PostgreSQL-oriented proposals**. They may be used only as a *vocabulary* when comparing against the real schema.
