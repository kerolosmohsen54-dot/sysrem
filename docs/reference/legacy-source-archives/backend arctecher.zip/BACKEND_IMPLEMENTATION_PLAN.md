# Implementation Plan [PROPOSED]
| Phase | Content | Depends on | Exit gate |
|---|---|---|---|
| 0 | Provide approved schema DDL; sign decisions D1–D10 (those blocking each phase); verify server PHP/MySQL | owner | Mapping doc completed & verified |
| 1 (**recommended first**) | Skeleton: Laravel in existing-schema mode, config, error envelope, request-id, logging, DB layer, health endpoint, schema-verify, CI, test DB | Phase 0 (schema) | Green CI; no migrations present |
| 2 | Auth, users, roles/permissions, throttling, audit writer | schema for users/roles; permissions matrix | 401/403 tests pass for all routes |
| 3 | Master data: customers, products, locations, settings | D10 | CRUD + validation tests |
| 4 | Inventory ledger: balances, movements, transfers, damaged, adjustments | ledger exists in schema; accounting policy for adjustments | Concurrency + reconciliation tests |
| 5 | Sales: drafts, post, reverse, returns, receipts/allocations | D1,D2,D4,D5, return rules | E2E scenario |
| 6 | Containers + landed cost | D2,D3 | Once-only receive; cost tests |
| 7 | Finance: treasuries, expenses, transfers, void, journals | chart of accounts policy | Balanced ledger |
| 8 | Orders/Deliveries | D8 | only if approved |
| 9 | Reports + exports | formulas defined | reconcile with ledger |
| 10 | Data migration from localStorage export, hardening, backup drill, go-live | cut-off date, accountant sign-off | Prod checklist |
Reason for ordering: security and master data first; inventory and sales are the base for most other modules.
