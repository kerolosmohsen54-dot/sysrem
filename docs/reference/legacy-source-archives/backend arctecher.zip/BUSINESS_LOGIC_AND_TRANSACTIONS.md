# Business Logic & Transactions

**No financial rule is decided here.** Each workflow lists boundaries; undecided parameters are policies read from settings and block production use.

## Observed current behavior [VERIFIED]
- Invoice creation computes totals in the browser, mutates `c.balanceNum` and stock, stores `noTax:true`, and a return is the same record with `isReturn:true` (`DB.invoices[no]`).
- Stock is held in several places (`INV_CATALOG[..].stock`, `LOCS` per warehouse, `DMG`, `TRF`) and edited directly, with `addMovement` as a side-log.
- Invoice status derived: `مدفوعة / مدفوعة جزئيًا / غير مدفوعة / متأخرة / مرتجع`.
- Inconsistent display: a 15% VAT in some static views vs `noTax` in the working flow.

## Workflows & transaction boundaries [PROPOSED]
| Workflow | Single transaction contains | Locks | Blocked by |
|---|---|---|---|
| Post invoice | status change, stock-out movements, receivable effect, optional COGS, audit, idempotency record | stock rows by (product,location) in deterministic order; document row | D1 D2 D4 D5 |
| Reverse invoice | reversal doc/movements, stock back, receivable reversal, audit with mandatory reason | invoice + stock rows | D5, accounting policy |
| Return | return doc linked to origin, qty ≤ returnable, stock-in (good) or damaged location, credit effect | origin lines, stock rows | return calc rules |
| Receipt | receipt, treasury entry, allocations (Σ ≤ amount, ≤ outstanding) | invoices, treasury | rounding |
| Stock transfer | out + in movement | both locations' stock rows | – |
| Adjustment | signed movement + mandatory reason; financial effect | stock rows | accounting policy |
| Expense / treasury transfer / void | entry/entries (void = opposite entry, never delete) | treasury rows | chart of accounts |
| Container receive | once-only flag, stock-in per line with landed unit cost, cost status, journal | container row | D2 D3 |

## Invariants (testable)
Posted documents immutable; balances derived from ledger; no negative stock unless policy allows; sequences unique (DB unique constraint if schema has one, else serialized allocation); all money via exact decimals; every state change audited.

## Unresolved policies (settings, default OFF/unset)
D1 currency/tax/rounding · D2 costing method · D3 landed-cost allocation · D4 credit limit warn/block · D5 edit posted · D6 markup visibility · D7 actor nature · D8 orders/delivery scope · D9 supplier AP · D10 duplicate names · reservation/availability rules · refund rules · customer/supplier balance definition · journal generation.
