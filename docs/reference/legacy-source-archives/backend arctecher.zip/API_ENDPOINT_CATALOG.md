# API Endpoint Catalog — all **[PROPOSED]**, pending schema verification and frontend coordination

Base: `/api/v1`. Auth: bearer/session per `AUTHENTICATION_AND_AUTHORIZATION.md`. Permission names are proposals. "Idem" = requires `Idempotency-Key`. "Tx" = single DB transaction. "Gate" = blocked decision.

## Auth & users
| Method Path | Purpose | Permission | Idem/Tx | Gate |
|---|---|---|---|---|
| POST /auth/login | Login | public, throttled | – | schema (users) |
| POST /auth/logout | Revoke session | auth | – | |
| GET /auth/me | Current user + permissions | auth | – | |
| GET/POST /users, GET/PATCH /users/{id} | User admin | users.manage | Tx | D7 |
| PUT /users/{id}/roles | Assign roles | users.manage | Tx | permissions matrix |
| POST /users/{id}/reset-password | Admin reset | users.manage | | |

## Customers
| GET /customers (q,page,limit,status) | List | customers.read | | |
| POST /customers · PATCH /customers/{id} | Create/update | customers.write | | D10 uniqueness |
| GET /customers/{id}/statement?from&to | Account statement derived from documents | customers.statement | | D1, balance rule |

## Catalog & locations
| GET/POST/PATCH /products | Products | products.read/write | | pricing, D6 |
| GET/POST/PATCH /locations | Warehouses/sub/car/damaged | locations.* | | D7 |

## Inventory
| GET /inventory/balances?product&location | Balances from ledger | inventory.read | | ledger exists? |
| GET /inventory/movements | Movement history | inventory.read | | |
| POST /inventory/transfers | Out+in atomically | inventory.transfer | Idem, Tx | |
| POST /inventory/adjustments | Reasoned adjustment | inventory.adjust | Idem, Tx | accounting effect |
| POST /inventory/damaged · POST /inventory/damaged/{id}/restore | Mark damaged / restore | inventory.damage / .restore | Idem, Tx | |

## Sales
| GET /sales/invoices · GET /sales/invoices/{id} | List/detail/print data | sales.read | | |
| POST /sales/invoices | Create draft (no stock/ledger effect) | sales.create | Idem | |
| POST /sales/invoices/{id}/post | Post: stock out + receivable (+COGS if approved) | sales.post | Idem, Tx | D1,D2,D4,D5 |
| POST /sales/invoices/{id}/reverse | Reverse posted invoice | sales.reverse | Idem, Tx | D5 |
| POST /sales/invoices/{id}/returns | Return against invoice | sales.return | Idem, Tx | return rules |
| GET /sales/returns · GET /sales/returns/{id} | Return docs | sales.read | | |
| POST /sales/receipts · GET /sales/receipts | Collection + allocation | collections.write/read | Idem, Tx | |

## Finance
| GET /finance/treasuries · GET /finance/treasuries/{id}/entries | Treasury ledger | finance.read | | |
| POST /finance/expenses | Expense | finance.expense | Idem, Tx | accounts |
| POST /finance/transfers | Treasury transfer | finance.transfer | Idem, Tx | |
| POST /finance/entries/{id}/void | Reversal | finance.void | Idem, Tx | |
| GET/POST /finance/currencies, /finance/adjustments | Per `currencies`, `financial-adjustments` screens (admin-only in UI) | finance.admin | Tx | D1 |

## Containers
| GET/POST /containers · GET /containers/{id} | Containers | containers.* | | |
| POST /containers/{id}/costs | Cost line | containers.cost | Idem, Tx | D3 |
| POST /containers/{id}/receive | One-time receive + landed cost | containers.receive | Idem, Tx | D2,D3 |

## Reports (GET, read-only)
`/reports/sales`, `/reports/profit`, `/reports/inventory`, `/reports/financial`, `/reports/dashboard` — permission `reports.*`; formulas **blocked** (profit on D2/D6; financial on accounting policy).

## Admin
`GET /admin/audit` (audit.read) · `GET/PUT /settings` (settings.manage; companies, WhatsApp numbers, theme is client-only).

## Conditional (not in scope until approved)
Orders/Deliveries (D8): `/orders`, `/deliveries`; Suppliers/Purchases (D9); Markups `/admin/markups` (D6).

Not provided: `PUT/DELETE` on posted financial documents (correction = reverse + reissue).
