# API Contracts [PROPOSED — coordinate with Frontend Architecture before freezing]

Field-level payloads depend on the unverified schema; shapes below define the **envelope and conventions** plus representative contracts. Money values are **decimal strings** (e.g. `"1250.50"`), never JSON floats. Dates ISO-8601.

## Headers
`Authorization`, `Content-Type: application/json`, `Accept-Language: ar`, `X-Request-Id` (echoed back), `Idempotency-Key` (UUID, required on marked POSTs).

## Success envelope
```json
{ "data": { }, "meta": { "request_id": "…" } }
```
List: `{ "data": [ ], "meta": { "page": 1, "limit": 25, "total": 130, "request_id": "…" } }`
Query: `page`, `limit` (max 100), `q`, `from`, `to`, `status`, `sort=-created_at`.

## Error envelope
```json
{ "error": { "code": "INSUFFICIENT_STOCK", "message": "…", "details": [ { "field": "lines.0.qty", "issue": "exceeds_available" } ] }, "meta": { "request_id": "…" } }
```
| HTTP | Meaning | Example codes |
|---|---|---|
| 400 | Malformed/validation | VALIDATION_FAILED |
| 401 | Not authenticated | UNAUTHENTICATED, TOKEN_EXPIRED |
| 403 | Not permitted | FORBIDDEN |
| 404 | Not found | NOT_FOUND |
| 409 | Conflict/duplicate/concurrency | DUPLICATE_DOCUMENT, IDEMPOTENCY_REPLAY_MISMATCH, ALREADY_POSTED, ALREADY_RECEIVED |
| 422 | Business rule | INSUFFICIENT_STOCK, CREDIT_LIMIT_EXCEEDED (if D4=block), OVER_RETURN, OVER_ALLOCATION, UNBALANCED_ENTRY |
| 429 | Rate limited | TOO_MANY_ATTEMPTS |
| 500 | Generic; no internals leaked | INTERNAL_ERROR |

Idempotency: same key + same body hash → original response replayed (`Idempotent-Replayed: true`); same key + different body → 409.

## Representative contracts

### POST /auth/login
Req `{ "username": "…", "password": "…" }` → 200 `{ "data": { "token"|session, "expires_at", "user": { "id","name","roles":[],"permissions":[] } } }`. Failures return one generic `UNAUTHENTICATED` (no user enumeration). Throttled.

### POST /sales/invoices (draft)
Req (proposed; fields grounded in HTML invoice object)
```json
{ "customer_id": 1, "issuer_id": 2, "driver": "…", "payment_terms": "…", "due_date": "2026-11-01",
  "notes": "", "discount": "0.00",
  "lines": [ { "product_id": 10, "location_id": 3, "qty": "2.000", "unit_price": "100.00" } ] }
```
Validation: customer exists/active; lines ≥1; qty > 0; price ≥ 0; discount ≤ subtotal; due_date ≥ issue date. **Server recomputes totals; client totals ignored.** 201 → draft document with server number (number assigned at post or create — **open**, see D-Numbering).

### POST /sales/invoices/{id}/post
Req `{}` + `Idempotency-Key`. Tx: lock lines' stock rows → verify availability → write stock-out movements → write receivable/ledger effect → (COGS if approved) → status=Posted → audit. 409 `ALREADY_POSTED` on repeat; 422 `INSUFFICIENT_STOCK`.

### POST /sales/receipts
Req `{ "customer_id","treasury_id","method","amount","reference","allocations":[{"invoice_id","amount"}] }` — Σallocations ≤ amount; each ≤ invoice outstanding.

### POST /inventory/transfers
Req `{ "from_location_id","to_location_id","lines":[{"product_id","qty"}],"note" }` — from≠to; atomic out+in.

### POST /containers/{id}/receive
Req `{ "location_id","received_at","allocation_strategy":"value|qty|weight" }` (strategy value pending D3). 409 `ALREADY_RECEIVED` on second call.

## Items needing frontend coordination
Number format of money/qty; whether numbers are assigned at draft or post; token vs cookie session; list column sets; print payload for invoice; Arabic message catalogue; whether client sends `issuer` as id or name (HTML currently uses Arabic names).
