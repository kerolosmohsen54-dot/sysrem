# Authentication & Authorization

## Current state [VERIFIED in HTML]
Default password `1234` (customer balances gate, edit password hash seeded from `'1234'`, admin shortcut at v45 block); role is an integer in `localStorage['ps-role']` with a user-switchable dropdown (1 موظف / 2 محاسب / 3 مدير); `ALLOW={1:['fin-overview','f-receipts'],2:'*',3:'*'}`. None of this is acceptable as security; all is replaced.

## Proposed design
- **Password hashing:** Argon2id (`sodium` verified) else bcrypt; rehash on login if cost changes. No password in logs.
- **Session model (choose with frontend):** (A) Same-site cookie session (HttpOnly, Secure, SameSite=Lax) + CSRF token, best if SPA and API share a registrable domain; (B) opaque bearer tokens (hashed at rest, expiry, revocable) if origins differ. Default recommendation: **A when same parent domain**, else B. Either needs a storage place → depends on schema (Gap G-03).
- **Lifetime:** idle timeout and absolute lifetime configured in `config/erp.php`; logout and password change revoke sessions.
- **Brute-force:** throttle per username+IP; incremental delay; log failed attempts without the submitted password.
- **Authorization:** permission strings checked in `RequirePermission` middleware **and** re-checked in the service for sensitive actions (post, reverse, void, adjust, markup read). UI hiding is cosmetic.
- **Roles (starting point from the HTML, not a decision):** Employee (قبض/نظرة مالية only in current UI), Accountant, Admin. The blueprint adds issuer-style actors كراس / أبنوب / السائق whose nature (users vs partners vs locations) is **open (D7)**.

## Permission matrix
Blueprint matrix is mostly "decision required". Only certain: Admin has everything; user administration and audit are admin-only; markup visibility is per D6. Everything else must be signed off by the business before go-live. Until then default is **deny**.

## Tests
Every endpoint × (allowed user, forbidden user, anonymous) must return expected 2xx/403/401.
