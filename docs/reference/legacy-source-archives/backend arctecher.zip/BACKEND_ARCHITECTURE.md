# Precision Slate ERP — Backend Architecture

Status: **ANALYSIS / DESIGN ONLY.** Nothing here is implemented. Items marked **[VERIFIED]** come from the supplied files; **[PROPOSED]** are design choices awaiting approval; **[BLOCKED]** depend on information that was not supplied.

## 1. Inspected inputs [VERIFIED]

| Artifact | Findings |
|---|---|
| `precision-slate-erp-v43…html` (821,223 bytes, 6,383 lines) | Single-file Arabic/RTL frontend. 18 `<script>` blocks, 10 `<style>` blocks, **0** `fetch`/`XMLHttpRequest` calls → no backend integration exists. 29 `sec-*` screens. All state in JS objects (`DB`, `ST`, `LOCS`, `DMG`, `TRF`, `RDOC`…) persisted to `localStorage` (`ps-erp-v4`, `ps-fin2`, `ps-settings`, `ps-locs`, `ps-dmg`, `ps-trf`, `ps-retdocs`, `ps-wret`, `ps-cmov`, `ps-fix`, `ps-drivers`, `ps-expenses`, `ps-bd`, `ps-role`, …). |
| `Precision_Slate_ERP_Blueprint_AR (2).pdf` | Arabic blueprint dated 9 Oct 2026. Describes current behavior, gaps, open decisions D1–D10, and a **target** design. |
| Backend task brief (provided as document) | Confirmed decisions: PHP, MySQL/MariaDB, Hostinger VPS, REST/JSON/HTTPS, **approved schema is immutable**. |
| SQL / migrations / ERD / DBML / `composer.json` / `.php` files | **None found** in the workspace (searched whole filesystem). |

## 2. Critical findings

1. **The approved MySQL/MariaDB schema was NOT supplied.** No `.sql`, migration, ERD, or DB documentation exists. Therefore no table or column is verified. `DATABASE_SCHEMA_MAPPING.md` is intentionally a *requirements-to-schema checklist*, not a mapping. No replacement schema has been invented.
2. **The blueprint conflicts with the confirmed decisions.** It proposes Node.js/Express + PostgreSQL + Prisma + UUID keys + `NUMERIC(18,2)`. Per your confirmed decisions, those are **discarded**; only the blueprint's *functional* content (workflows, gaps, decisions D1–D10) is used. Blueprint table names (`sales_documents`, `stock_movements`, …) are **proposals, not facts**.
3. The current frontend has no server-enforced security: default password `1234` (lines ~4441, 5052, 6365), role stored in `localStorage` (`ps-role`, line ~4787) and switchable from a dropdown, permissions map `ALLOW={1:[…],2:'*',3:'*'}` (line ~4820) is UI-only.
4. Business rules in the frontend are inconsistent (invoices flagged `noTax:true` while some screens show 15% VAT; currency shown as ج.م in places and Riyadh warehouse label elsewhere). These are open decisions, not defaults.

## 3. Stack recommendation [PROPOSED]

| Option | Pros | Cons |
|---|---|---|
| **Laravel** (recommended) | Mature auth, validation (FormRequest), rate limiting, queues/scheduler, exception mapping, testing tooling, Hostinger-VPS friendly | Heavier; its migrations/Eloquent conventions assume you own the schema |
| Structured native PHP (PSR-4 + a micro-router + PDO) | Total control, small footprint | We would hand-build auth, throttling, validation, DI, testing glue → more security risk for an ERP |

**Recommendation: Laravel, used in "existing schema" mode:**
- `php artisan migrate` is **never run** against production; `database/migrations/` is not created for the approved tables. A CI check fails if migration files appear without an approved Schema Change Request.
- Database access via **Query Builder / PDO in repository classes** with explicit column lists. Eloquent models, if used at all, are read-mapping only (`$timestamps`, `$table`, `$primaryKey` set explicitly) and only after the schema is verified. No ORM-driven schema changes.
- Auth tables: Laravel's default `users`/`personal_access_tokens`/`sessions` tables **cannot be assumed**. Authentication must use the approved schema's user table; if it lacks token/session storage, see Gap G-03 (a schema change or stateless signed tokens).

Version/extension requirements are **not assumed**. Procedure: (a) run `php -v && php -m` on the VPS; (b) choose the Laravel major whose `composer.json` PHP constraint matches the installed/installable PHP; (c) record results in `HOSTINGER_VPS_DEPLOYMENT.md`. Likely extensions to verify: `pdo_mysql`, `mbstring`, `openssl`, `json`, `ctype`, `tokenizer`, `xml`, `bcmath` (for exact money math), `intl` (Arabic formatting, optional), `sodium` (Argon2id).

## 4. Architectural style [PROPOSED]

Modular monolith, layered inside each module:

`Route → Middleware → FormRequest (validation) → Controller (thin) → Service/UseCase → Repository (SQL) → MySQL`

- Controllers contain no business rules or SQL.
- Services own transaction boundaries (`DB::transaction` / PDO `beginTransaction`) and call repositories + audit writer.
- Money handled as **integer minor units or `bcmath` strings** — never PHP floats. Precision/rounding rules are **[BLOCKED on D1 + column types]**.
- API versioned under `/api/v1`, JSON only, uniform envelope (see `API_CONTRACTS.md`).

## 5. Modules (derived from the 29 real screens)

| Module | Screens | Status |
|---|---|---|
| Auth & Users | users, settings | Required (replaces fake login/role) |
| Customers | customers, accounts-customer | Required |
| Products & Warehouses/Locations | products, warehouses | Required |
| Inventory | inventory-summary, movements, adjustments, transfers, damaged | Required |
| Sales (Invoices, Collections, Returns) | invoices, invoice-create, invoice-print, collections, returns, return-create | Required |
| Finance | finance (treasuries, receipts, expenses, transfers), currencies, financial-adjustments | Required, **rules blocked** |
| Containers & Landed Cost | containers, container-receive, landed-cost | Required, **rules blocked on D2/D3** |
| Reports | reports, -sales, -profit, -inventory, -financial | Required, formulas to be defined |
| Orders & Deliveries | orders, create-order, detail-order, deliveries, create-delivery | **Conditional on D8** |
| Audit | (admin) | Required |
| Suppliers / Purchases | — | **Conditional on D9**; no dedicated screen found |

Excluded until approved: Orders/Deliveries (D8), Suppliers/AP (D9), partner installments (D7).

## 6. Cross-cutting
Error handling, logging, security, tests, deployment: see the dedicated documents. Files in this folder do not overwrite any existing documentation.
