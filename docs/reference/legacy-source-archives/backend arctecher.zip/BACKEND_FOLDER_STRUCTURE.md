# Backend Folder Structure [PROPOSED — Laravel, existing-schema mode]

Only directories justified by verified screens are listed. Modules in *italics* are conditional on decisions D7–D9.

```
precision-slate-api/
├── composer.json / composer.lock        # PHP constraint set AFTER server verification
├── .env.example                         # placeholders only; real .env never committed
├── artisan, public/index.php            # single web entry; web root = public/
├── bootstrap/app.php                    # middleware, exception mapping registration
├── config/                              # app, database, auth, cors, logging, erp (policies as settings)
├── routes/api_v1.php                    # all /api/v1 routes, grouped by module
├── app/
│   ├── Http/
│   │   ├── Middleware/                  # RequestId, Authenticate, RequirePermission, Idempotency, ForceJson
│   │   ├── Requests/<Module>/           # FormRequest validation per endpoint
│   │   ├── Controllers/<Module>/        # thin; call one Service method
│   │   └── Resources/<Module>/          # explicit response serializers (whitelist fields)
│   ├── Modules/                         # business capabilities
│   │   ├── Auth/        (Services, Repositories)
│   │   ├── Users/
│   │   ├── Customers/
│   │   ├── Catalog/                     # products, categories, units
│   │   ├── Inventory/                   # movements, transfers, adjustments, damaged
│   │   ├── Sales/                       # invoices, returns, collections/receipts, allocations
│   │   ├── Finance/                     # treasuries, expenses, transfers, void
│   │   ├── Containers/                  # containers, costs, receive, landed cost
│   │   ├── Reports/                     # read-only query services
│   │   ├── Audit/
│   │   ├── Settings/
│   │   ├── *Orders/*  *Deliveries/*     # only if D8 approved
│   │   └── *Suppliers/*                 # only if D9 approved
│   ├── Support/
│   │   ├── Money/                       # bcmath-based Money/Quantity value objects, rounding policy
│   │   ├── Database/TransactionRunner.php  # retry on deadlock, isolation, FOR UPDATE helpers
│   │   ├── Idempotency/                 # key store + replay logic
│   │   ├── Pagination/ , Errors/ (DomainException hierarchy → HTTP map)
│   │   └── Audit/AuditWriter.php        # append-only writer
│   └── Console/Commands/                # reconciliation, schema-verify (read-only), backup hooks
├── tests/
│   ├── Unit/ (Money, rounding, policies)  Feature/ (API + RBAC)  Integration/ (DB, concurrency)
│   └── Support/ (fixtures loader, test DB bootstrap)
├── docs/ (this folder, openapi.yaml later)
└── deploy/ (nginx.conf.example, php-fpm pool example, supervisor.conf, deploy.sh, backup.sh)
```

## Responsibilities
| Path | Purpose | Depends on |
|---|---|---|
| `routes/api_v1.php` | Declares endpoints, attaches `auth`, `permission:*`, `idempotent` middleware | Middleware, Controllers |
| `Http/Requests` | Input validation only; no DB writes | Support/Money rules |
| `Modules/*/Services` | Workflow + transaction boundary + audit | Repositories, Support |
| `Modules/*/Repositories` | The **only** place SQL lives; explicit columns; prepared statements | `DATABASE_SCHEMA_MAPPING.md` (verified schema) |
| `Support/Money` | Exact decimal arithmetic, rounding per approved D1 policy | `bcmath` |
| `Support/Database/TransactionRunner` | Wraps tx, deadlock retry, lock ordering | PDO |
| `Console/Commands/schema-verify` | Read-only comparison of live schema vs approved mapping (SELECT on `information_schema` only) | DB read user |

Not created (no verified need): GraphQL, event-sourcing, microservice folders, generic "BaseRepository" abstractions, file-upload storage (no upload feature found in the HTML; logo/attachments to be confirmed), email/SMS integration (the HTML uses `wa.me` WhatsApp links client-side only; server integration unconfirmed), queue workers (add only if reports/exports prove slow).
