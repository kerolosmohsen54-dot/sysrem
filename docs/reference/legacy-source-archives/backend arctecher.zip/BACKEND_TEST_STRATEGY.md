# Backend Test Strategy
Tooling [PROPOSED]: PHPUnit/Pest, Laravel HTTP tests, a **separate disposable MySQL/MariaDB test database** loaded from the approved DDL once supplied (never the production DB). Tests never run migrations against production.

| Layer | Scope | Examples |
|---|---|---|
| Unit | Money/rounding, status derivation, policies | rounding vectors signed by business (D1) |
| Integration (DB) | Repositories and services with real DB | post-invoice rollback if movement insert fails; unique number; ledger-derived balance |
| Concurrency | Two parallel posts of last unit; duplicate receive; duplicate idempotency key | exactly one succeeds |
| API/Feature | Every endpoint: validation 400, 401, 403, 404, 409, 422, success | RBAC matrix test generated from route list |
| Security | Login throttling, CSRF/CORS, no secrets in responses/logs, SQLi probes | |
| Reconciliation | Stock = Σmovements; customer balance = docs − allocations; debit = credit; treasury = Σentries | run nightly + in CI on fixtures |
| E2E scenario | Blueprint §15: customer+product+location → opening stock → draft → post → partial receipt → second receipt → good return / damaged return → reconcile → unauthorized user rejected | |
| Schema guard | Read-only check live schema == approved mapping; CI fails on migration files | |
Acceptance: all above pass; expected values come from business-approved examples, not from the code under test.
