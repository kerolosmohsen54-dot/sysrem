# Decisions, Gaps, Assumptions, Approvals

## Missing information
| ID | Gap | Blocks |
|---|---|---|
| G-01 | **Approved MySQL/MariaDB schema not provided** | All mapping, repositories, endpoint field contracts, tests with real DB |
| G-02 | MySQL/MariaDB version; Hostinger PHP version/extensions | Laravel major choice, JSON/CTE use |
| G-03 | Whether schema has token/session storage, roles, audit, idempotency, sequences | Auth model, idempotency, numbering (may need Schema Change Requests) |
| G-04 | Blueprint targets Node/PostgreSQL/UUID — contradicts confirmed PHP/MySQL decisions | Confirm blueprint tech sections are superseded; UUID vs existing keys |
| G-05 | Frontend integration: session vs token, payload field names, Arabic vs id identifiers | API freeze |
| G-06 | Whether file uploads, email/SMS, server-side WhatsApp are required | Optional modules |
| G-07 | Source reports' formulas (sales, profit, inventory, financial) | Reports module |

## Business decisions (from blueprint; **unresolved**)
D1 currency/tax/rounding (HTML mixes ج.م EGP, "15% VAT" displays, and `noTax:true`) · D2 costing (weighted avg vs FIFO) · D3 landed-cost allocation · D4 credit limit warn/block · D5 edit of posted invoice (recommended: no, reverse+reissue) · D6 markup visibility/ownership · D7 nature of كراس/أبنوب/السائق · D8 orders/deliveries in MVP · D9 supplier as entity/AP · D10 customer name uniqueness. Also: permission matrix, return/refund calculations, stock reservation, journal templates (accountant review), cut-off & opening balances.

## Assumptions made (flag if wrong)
Laravel recommended; money as exact decimals; posted documents immutable; deny-by-default permissions; blueprint SQL names treated as vocabulary only.

## Schema Change Requests
None raised yet (cannot be evaluated without G-01). Each future request must state reason, impact, migration proposal, and await explicit approval.

## Frontend defects relevant to backend (for hand-off)
Hard-coded `1234`; localStorage role; multiple stock sources; floating-point math; returns as `isReturn` invoices; return flow via click/setTimeout; unescaped HTML string building.
