# State Management and Data Flow

## 1. State taxonomy
| Kind | Tool | Examples | Persistence |
|---|---|---|---|
| Server state | TanStack Query | customers, invoices, products, balances, reports | memory cache only |
| Session state | `AuthProvider` + Zustand | `currentUser`, `permissions` | memory; rehydrated from `GET /auth/me` |
| UI state | Zustand / local `useState` | sidebar groups, mobile nav, theme, notifications panel, dialogs | theme + sidebar → `localStorage` (non-sensitive) |
| Form state | React Hook Form | invoice draft, return, container receipt | memory; optional unsaved-draft in `sessionStorage` |
| URL state | React Router | filters, page, sort, tab, search term | URL |

**Not allowed in the browser:** passwords, hashes, role numbers, financial balances, stock counts, invoice sequences, audit log. These are the exact items the MVP keeps in `localStorage` (`ps-cust-pw`, `ps-edit-pw-h`, `ps-role`, `ps-fin2`, `ps-erp-v4`, `SEQ`).

## 2. Query keys (central factory)
`['customers', {page,q,status}]`, `['customer', id]`, `['customer-statement', id, range]`, `['invoices', filters]`, `['invoice', id]`, `['products', filters]`, `['stock-balance', {productId, locationId}]`, `['movements', filters]`, `['treasury-accounts']`, `['ledger', filters]`, `['containers']`, `['report', name, params]`, `['dashboard']`, `['me']`.

## 3. Caching policy
| Data | staleTime | Why |
|---|---|---|
| `me`, settings, reference lists (governorates, payment methods, currencies) | long (5–15 min) | rarely change |
| products, customers lists | 30 s | moderately dynamic |
| stock balances, customer balance, treasury balances | 0–5 s + refetch on focus | money/stock accuracy |
| reports | 60 s; manual refresh | expensive |
| dashboard | 30 s | |

## 4. Mutations and invalidation
| Mutation | Invalidate |
|---|---|
| create customer / update | `customers`, `customer` |
| post invoice | `invoices`, `invoice`, `customers`, `customer-statement`, `stock-balance`, `movements`, `dashboard`, `ledger`, `collections` |
| reverse invoice | same set as post |
| create receipt | `invoices`, `invoice`, `collections`, `customer-statement`, `customers`, `treasury-accounts`, `ledger`, `dashboard` |
| create return | `invoices`, `returns`, `stock-balance`, `movements`, `customer-statement`, `ledger` |
| stock adjustment / transfer / stock-in | `stock-balance`, `movements`, `products`, `inventory-summary` |
| receive container | `containers`, `products`, `stock-balance`, `movements`, `ledger` |
| expense / transfer / void entry | `treasury-accounts`, `ledger`, `journal`, `trial-balance` |

Rule: **no optimistic updates for financial or stock mutations.** The UI waits for the server result. Optimistic UI is allowed only for non-financial toggles (e.g., notification read).

## 5. Key flow: issue invoice
```
InvoiceForm (RHF+Zod)
  ├─ product search → GET /products?q= (debounced)
  ├─ customer select → GET /customers/:id (balance, credit limit) → CreditBanner (advisory)
  ├─ preview totals (client, decimal-string math; labeled "تقديري" until server confirms)
  └─ submit
       ├─ key = useIdempotencyKey() (generated when form opens, reused on retry)
       ├─ POST /sales/invoices            → draft id
       ├─ POST /sales/invoices/:id/post   (Idempotency-Key)
       ├─ [collect-now] POST /receipts    (Idempotency-Key)
       └─ on success: invalidate set (§4) → navigate /sales/invoices/:id → toast
  errors: 409 duplicate → open existing document; 422 insufficient stock → inline per line; 5xx → keep form, show retry + request id
```
Double-submit protection: submit button disabled while pending; same key on retry.

## 6. Key flow: return
Pick original invoice → fetch returnable quantities → per line choose quantity ≤ returnable and condition (sound/damaged) → `POST …/returns`. The UI cannot exceed returnable quantity; server re-validates. (Replaces MVP's `isReturn` flag + `click/setTimeout` detection.)

## 7. Auth flow
App boot → `GET /auth/me` → 200: build nav from permissions; 401: `/login`. Any 401 later → clear session, redirect with `next`. Idle timeout and warning (the MVP settings have "session end after N min / warn before N min") → client timer shows warning dialog, server remains authoritative.

## 8. Error flow
`http` client throws `ApiError` → query/mutation `onError` → (a) field errors set on RHF, (b) toast for generic, (c) route `ErrorBoundary` for render failures. Global handler logs request id.

## 9. Loading/empty/error rules
| State | Presentation |
|---|---|
| First load | skeleton rows (tables), spinner (forms) |
| Refetching | subtle top progress; stale data stays visible |
| Empty | existing text "لا توجد بيانات" (+ CTA where the MVP had one) |
| Error | inline banner with retry and request id |
| Success | toast (type, title, message) like MVP |
| Destructive | `ConfirmDialog` |

## 10. Offline / PWA
MVP links a manifest and has a "install as app" page (`x-app`). Offline write queues for financial documents are **out of scope** (dangerous without server idempotency). Read-only caching of the shell is optional (Decision F-09).
