# Frontend Component Catalog

Rule: a component enters `shared/ui` only if it is used by **two or more features** in the MVP. Everything else stays in its feature.

## A. Layout (`app/layout`)
| Component | Responsibility | MVP origin |
|---|---|---|
| `AppShell` | grid: sidebar + main; hosts `<Outlet/>` and toasts | `body` flex, `.sidebar`, `.main` |
| `Sidebar` | renders `navigation.config.ts`; groups, collapsible sub-lists, badges, active state, keyboard (Enter/Space) | `.nav-group`, `toggleSub`, v43 a11y |
| `Topbar` | breadcrumb, search trigger, notifications, avatar menu | `.topbar` |
| `Breadcrumb` | built from route `handle.title` | `NAMES` + `#breadcrumb` |
| `NotificationPanel` | list of notifications (data source unverified) | `#notif-panel`, `toggleNotif` |
| `GlobalSearch` | Ctrl+K overlay; grouped results (customers/invoices/products) | `toggleSearch`, `runGlobalSearch` |
| `MobileNavToggle` | opens sidebar < 768px | v42 |

## B. Primitives (`shared/ui`)
| Component | Variants / notes |
|---|---|
| `Button` | primary, ghost, danger; sizes md/sm (`.btn`, `.btn-sm`); loading state |
| `IconButton` | `.icon-btn`, `.tbl-btn` |
| `Badge` / `StatusBadge` | accent, success, warning, danger, info; `StatusBadge` takes a domain status and maps to a variant via per-feature maps |
| `Card`, `StatCard` | `.card`, `.stat-card` (label, value, optional trend, color) |
| `PageHeader` | title, subtitle, actions (`.page-hd`) |
| `Tabs` | customer modal tabs, user-settings tabs |
| `Tooltip`, `Spinner`, `Skeleton` | Skeleton/Spinner are **new** (loading state); minimal, same tokens |
| `EmptyState` | the existing empty-row text pattern, plus optional CTA |
| `Avatar` | initials |

## C. Forms (`shared/ui/Form`)
| Component | Notes |
|---|---|
| `Field` | label + control + error + hint; wires `aria-describedby` |
| `Input`, `Textarea`, `Select`, `Checkbox`, `Toggle` | `.input` styling |
| `MoneyInput` | decimal string in/out; no float math |
| `QuantityInput` | scale per product unit (3 decimals proposed) |
| `DateInput` | date; Cairo timezone default pending |
| `PaymentMethodSelect` | cash / wallet / bank / carrier — values to confirm |
| `AsyncSelect` + `CustomerPicker`, `ProductPicker` (name/code/barcode), `WarehouseSelect`, `UserSelect` | debounced server search |
| `LineItemsEditor` | generic editable lines grid used by invoice, order, return, delivery, adjustment, container receipt (6 MVP forms reimplement this) |
| `FormActions` | Cancel / Save draft / Submit area with shortcut hints |

## D. Data display (`shared/ui/DataTable`)
| Part | Responsibility |
|---|---|
| `DataTable` | columns, server-driven sort/filter/page, row selection, loading/empty/error rows |
| `TableToolbar` | search box, filters, Export CSV button |
| `Pagination` | page/limit/total |
| `RowMenu` | `openRowMenu` equivalent |
| `BulkActionBar` | print / PDF / WhatsApp (invoices) |
| `DetailPanel` | customer detail side panel with sub-tables |
| `Money`, `Quantity`, `DateText` | display formatting components |

## E. Dialogs & feedback
| Component | MVP origin |
|---|---|
| `Modal`, `FormDialog` | `openModal/closeModal`, `dlg()` |
| `ConfirmDialog` | `modal-confirm` (cancel order, restore backup, confirm transfer, reconcile adjustments) |
| `ReauthDialog` (**proposed**) | replaces `prompt()` password gates; server-validated |
| `ToastProvider` + `useToast` | `showToast(type,title,msg)` |
| `PrintSheet` | invoice/delivery print wrapper using `print.css` |

## F. Feature components (representative, not exhaustive)
| Feature | Components |
|---|---|
| auth | `LoginForm`, `ChangePasswordForm` |
| dashboard | `KpiGrid`, `RecentActivityTable`, `OverdueWidget`, `DemoChart` (kept only if approved) |
| customers | `CustomerTable`, `CustomerFormDialog` (tabs: basic, financial, attachments), `CustomerDetailPanel`, `StatementTable`, `CustomerBalancesTable`, `RepeatLastInvoiceButton` |
| sales | `InvoiceTable`, `InvoiceForm`, `InvoiceLinesEditor`, `ReturnToggleSection`, `CollectNowSection`, `CustomerCreditBanner`, `InvoicePreview`, `InvoicePrintLayout`, `CollectionsTable`, `ReceiptDialog` |
| returns | `ReturnTable`, `ReturnForm` (item condition, receiving warehouse) |
| orders | `OrderTable`, `OrderForm`, `OrderDetailTabs` (items, pricing, reservations, deliveries, invoices), `ReservationPanel` |
| deliveries | `DeliveryTable`, `DeliveryForm`, `DeliveryPrint` |
| inventory | `ProductTable`, `ProductFormDialog`, `WarehouseTable`, `WarehouseFormDialog`, `StockSummaryCards`, `MovementTable`, `AdjustmentForm`, `StockInForm`, `MinStockTable`, `CountSheet`, `BarcodeLabel` |
| finance | `FinanceNav`, `TreasuryTable`, `ReceiptForm`, `PaymentForm`, `ExpenseDialog`, `TransferForm`, `CoaTree`, `JournalTable`, `LedgerTable`, `TrialBalanceTable`, `FinancialAdjustmentForm`, `CurrencyTable`, `PartnerTable`, `InstallmentSchedule`, `PurchaseInvoiceTable` |
| containers | `ContainerTable`, `ContainerFormDialog`, `ReceiveItemsTable`, `CostsTable`, `LandedCostTable`, `AllocationStrategySelect` (pending D3) |
| reports | `ReportCard`, `ReportFilters` (period/status), `SalesByRepTable`, `ProfitTable`, `InventoryValuationTable`, `ExportButton` |
| admin | `UsersTable`, `UserForm`, `PermissionMatrix`, `PasswordPolicyForm`, `SessionPolicyForm`, `CompanySettingsForm`, `NumberingForm`, `BackupPanel`, `AuditTable`, `TrashTable`, `ExcelImportWizard` |

## G. Conventions
- Components receive data via props or feature hooks; shared UI never fetches.
- No `dangerouslySetInnerHTML`. The MVP's 234 `innerHTML` writes are replaced by JSX, which escapes by default.
- Status → badge mapping lives in `features/<x>/model/status.ts` so labels (e.g., Draft/Posted/Paid) are not scattered.
- Every component with interaction has an accessible name and keyboard path.
