# Frontend Folder Structure

Location: `apps/web/` inside the monorepo, or a standalone `web/` if you prefer. Every folder below has a stated job; none is a placeholder.

```
apps/web/
├─ index.html                       Vite entry; sets <html lang="ar" dir="rtl">, font preload
├─ package.json                     scripts: dev, build, preview, lint, typecheck, test, test:e2e
├─ vite.config.ts                   alias @/ → src/, dev proxy /api → backend, build target
├─ tsconfig.json                    strict mode, path aliases
├─ eslint.config.js                 typescript-eslint, jsx-a11y, import boundaries, ban innerHTML
├─ .prettierrc                      formatting
├─ .env.example                     VITE_API_BASE_URL only (no secrets)
├─ playwright.config.ts             e2e config
├─ vitest.config.ts                 unit/component config (jsdom)
├─ public/
│  ├─ manifest.webmanifest          PWA manifest (MVP links one; file not supplied)
│  ├─ icon-192.png / icon-512.png   referenced by MVP; to be supplied
│  └─ fonts/                        self-hosted IBM Plex Sans Arabic (replaces Google Fonts CDN)
├─ docs/                            (links to /docs/frontend and dev README)
└─ src/
   ├─ main.tsx                      mounts <App/>, no logic
   ├─ app/
   │  ├─ App.tsx                    composes providers + router
   │  ├─ providers/                 QueryClientProvider, AuthProvider, ToastProvider, ThemeProvider
   │  ├─ router/
   │  │  ├─ routes.tsx             route table (lazy-loaded feature routes)
   │  │  ├─ RequireAuth.tsx        redirects anonymous users to /login
   │  │  ├─ RequirePermission.tsx  403 panel when permission missing
   │  │  └─ NotFound.tsx
   │  ├─ layout/
   │  │  ├─ AppShell.tsx           sidebar + topbar + <Outlet/>
   │  │  ├─ Sidebar.tsx            renders navigation.config.ts, collapsible groups, badges
   │  │  ├─ Topbar.tsx             breadcrumb, global-search trigger (Ctrl+K), notifications, avatar menu
   │  │  ├─ Breadcrumb.tsx         from route handles (replaces NAMES map)
   │  │  ├─ MobileNavToggle.tsx    v42 behavior
   │  │  └─ navigation.config.ts   single source for menu + permissions
   │  └─ error/
   │     ├─ RouteErrorBoundary.tsx per-route fallback with request id
   │     └─ GlobalErrorHandler.ts  unhandled rejection → toast + log
   ├─ shared/
   │  ├─ api/
   │  │  ├─ client.ts              base fetch wrapper: base URL, credentials, headers, X-Request-Id, Idempotency-Key
   │  │  ├─ ApiError.ts            normalized error type
   │  │  ├─ pagination.ts          page/limit/total types and query-string helpers
   │  │  └─ queryKeys.ts           central query key factory
   │  ├─ ui/                       presentational only (see component catalog)
   │  │  ├─ Button, IconButton, Badge, StatusBadge, Card, StatCard, PageHeader, Tabs
   │  │  ├─ DataTable/             table, toolbar, pagination, row menu, bulk bar, empty/loading states
   │  │  ├─ Form/                  Field, Input, Select, DatePicker, MoneyInput, QuantityInput, Checkbox, Textarea
   │  │  ├─ Dialog/                Modal, ConfirmDialog, FormDialog
   │  │  ├─ Toast/                 toast container + hook
   │  │  ├─ ProductPicker, CustomerPicker, WarehouseSelect   async search selects
   │  │  └─ PrintSheet/            print-only wrappers
   │  ├─ hooks/                    useDebounce, useHotkey, useConfirm, useIdempotencyKey
   │  ├─ lib/
   │  │  ├─ money.ts               decimal-string helpers, formatCurrency (ج.م default; from settings)
   │  │  ├─ quantity.ts            formatting only
   │  │  ├─ date.ts                locale/timezone formatting, Cairo default (to confirm)
   │  │  ├─ csv.ts                 client-side CSV of visible rows
   │  │  └─ sanitize.ts            text escaping rules (no raw HTML rendering)
   │  ├─ config/
   │  │  ├─ constants.ts           page sizes, debounce, status maps
   │  │  └─ env.ts                 typed access to import.meta.env
   │  ├─ i18n/
   │  │  └─ ar.ts                  Arabic strings (single locale for now)
   │  └─ types/                    cross-feature primitives: Id, DecimalString, ISODate, Paged<T>
   ├─ features/                     one folder per ERP business area (details below)
   │  ├─ auth/
   │  ├─ dashboard/
   │  ├─ customers/
   │  ├─ sales/                     invoices, invoice create/print, collections
   │  ├─ returns/
   │  ├─ orders/                    (conditional on decision D8)
   │  ├─ deliveries/                (conditional on D8)
   │  ├─ inventory/                 products, warehouses, summary, movements, adjustments, stock-add, stock-return
   │  ├─ finance/                   treasury, receipts, payments, expenses, transfers, COA, journal, ledger, trial balance, adjustments, currencies
   │  ├─ containers/                list, receive, landed cost, container money, tracking
   │  ├─ partners/                  (conditional on D7)
   │  ├─ reports/
   │  ├─ search/                    global Ctrl+K search
   │  └─ admin/                     users/permissions, settings, audit log, trash, backup
   ├─ styles/
   │  ├─ tokens.css                 :root variables copied from MVP
   │  ├─ base.css                   reset, html/body, RTL, scrollbars
   │  ├─ print.css                  @media print rules from MVP
   │  └─ utilities.css              small layout helpers only
   ├─ assets/icons/                 SVG icons extracted from sidebar/topbar inline SVGs
   └─ test/
      ├─ setup.ts                   RTL + jest-dom + MSW lifecycle
      ├─ msw/handlers.ts            mock handlers per proposed contract
      ├─ factories/                 customer, product, invoice builders
      └─ render.tsx                 renderWithProviders helper
```

## Anatomy of every feature module

```
features/<area>/
├─ index.ts            public exports (routes, a few components); nothing else importable from outside
├─ routes.tsx          route objects for this area, with permission metadata
├─ pages/              page-level containers (one per route)
├─ components/         feature-specific components (tables, dialogs, forms)
├─ api/                <area>.api.ts service functions + <area>.types.ts request/response types
├─ hooks/              useXxxQuery / useXxxMutation wrapping TanStack Query
├─ model/              pure functions: validation schemas (Zod), calculators, status maps
└─ __tests__/          colocated tests
```

## Per-feature responsibilities

| Feature | Responsibility | MVP origin |
|---|---|---|
| `auth` | login page, session bootstrap, logout, change password, lockout messages | `#login-screen`, `doLogin`, `setRole`, prompt gates |
| `dashboard` | stat cards, recent activity table, quick actions, CSV export | `sec-dashboard`, `dashOD`, `toggleChart` |
| `customers` | list, add/edit (3-tab modal: basic/financial/attachments), customer file (`cust-file`), statement, account balances | `sec-customers`, `saveCustomer`, `cust-file`, `customer-accounts` |
| `sales` | invoice list (bulk actions), create (incl. return toggle, collect-now), preview/print, collections board | `sec-invoices`, `sec-invoice-create`, `sec-invoice-print`, `sec-collections`, `inv-detail` |
| `returns` | return list and create (linked to original invoice, item condition) | `sec-returns`, `sec-return-create`, `__retGo` flow |
| `orders` | order list/create/detail, reservations | `sec-orders`, `sec-order-create`, `sec-order-detail` |
| `deliveries` | delivery notes list/create | `sec-deliveries`, `sec-delivery-create`, `drivers` |
| `inventory` | products, warehouses, summary, movements, adjustments, stock add, returned stock, min stock, periodic count, barcodes, price history | `sec-products`, `warehouses`, `inventory-summary`, `movements`, `adjustments`, `stock-add`, `stock-ret`, `x-low`, `x-count`, `x-bar`, `x-price`, `move-detail` |
| `finance` | everything under the finance sidebar group | `finance`, `fin-overview`, `f-*`, `transfers`, `x-budget`, `x-recur`, `x-compare`, `x-cash`, `liq` |
| `containers` | container list/create, receive, landed cost, container money, tracking | `containers`, `container-receive`, `landed-cost`, `cont-money`, `x-track` |
| `partners` | partners and installment payments | runtime finance items "الشركاء", "دفعات الشركاء" |
| `reports` | report hub + 4 report pages + financial reports | `reports*`, `f-reports`, `f-stmt` |
| `search` | global search overlay | `runGlobalSearch`, `toggleSearch` |
| `admin` | users/permissions, security policy, company settings, backup/restore, audit log, trash, import from Excel, daily summary, PWA install | `users`, `settings`, `log`, `trash`, `x-import`, `x-daily`, `x-app` |

Folders deliberately **not** created: `store/` (no global business store needed), `services/` at root (services live in each feature), `utils/` (replaced by named `lib/` files), `pages/` at root (pages belong to features).
