# Frontend Feature Inventory

Source: `precision-slate-erp-v43.html`. Method: static extraction of all 29 `sec-*` blocks (headings, `<th>`, `<label>`, `onclick`), plus a headless-browser load that enumerated the **68 runtime screens** and the **runtime sidebar**.

**Status legend**
- **F** = functional in the MVP code path (touches local state)
- **P** = partial / local-only / depends on a patch override
- **S** = shell only: the original handler is just `showToast('success', …)` or a static message
- **U** = unverified at runtime: needs a scripted click-through before the port

> The 17 `onclick="showToast(…)"` buttons found in the static markup are S *as written*. Later patches may override some of them (e.g., payment and return flows), so each is tagged **S→U** until a Playwright characterization run confirms the effective behavior.

## 1. Screens (static, 29)

| # | Screen (id) | Title | Tables / columns | Forms / fields | Actions | Status | Target module |
|---|---|---|---|---|---|---|---|
| 1 | `dashboard` | لوحة التحكم | Recent activity: النوع، المرجع، الطرف، المبلغ، الوقت، الحالة | — | Export CSV, "إعداد الحسابات", "تسجيل أول فاتورة", toggle demo chart | P (stats computed from local data; chart toggle is demo) | `dashboard` |
| 2 | `customers` | العملاء | List: الاسم، الهاتف، العملة، حد الائتمان، الرصيد، الحالة; detail panel sub-tables: orders, invoices, payments, statement (مدين/دائن) | Add-customer modal (`modal-add-customer`, tabs basic/financial/attachments): اسم العميل*، رقم العميل*، البريد… | Export, Add, Repeat last invoice, Close detail, Record payment | F (localStorage); password-gated in patches | `customers` |
| 3 | `orders` | الطلبات | رقم الطلب، العميل، التاريخ، الإجمالي، الحجز، الحالة | — | Export, "+ إنشاء طلب" | U | `orders` |
| 4 | `order-create` | إنشاء طلب مبيعات | Lines: المنتج، الكود، المتاح، الكمية، السعر، الخصم %، الإجمالي | رقم الطلب (auto)، العميل*، التاريخ*، العملة*، المخزن*، شروط الدفع*، موظف المبيعات*، ملاحظات | Add line, Cancel, Save draft, Confirm & send | Save draft = S; Confirm = `confirmNewOrder` (F/P) | `orders` |
| 5 | `order-detail` | طلب مؤكد | Lines with tax (15%), pricing, reservations (رقم الحجز…), deliveries, invoices | — | Cancel order (confirm dlg), Reserve stock (S), Create delivery, Create invoice, Print preview, Export | Mostly S/U | `orders` |
| 6 | `invoices` | الفواتير | رقم الفاتورة، العميل، التاريخ، الاستحقاق، الإجمالي، المدفوع، المتبقي، طلّعها، الحالة | — | Print last, Export, Create, Bulk: print / PDF / WhatsApp | Create F; bulk actions U (`bulkAction`) | `sales` |
| 7 | `invoice-create` | إنشاء فاتورة | Lines: #، الصنف (search name/code/barcode)، الفئة، الكمية، السعر، الإجمالي | Is-return?، Collect-now?، العميل*، الهاتف، الرصيد، حد الائتمان، الفاتورة الأصلية*، سبب المرتجع، التاريخ/الوقت/رقم (auto)، شروط الدفع، الاستحقاق، السائق/المندوب، المخزن، المبلغ المحصّل، وسيلة الدفع، ملاحظات | Preview, Save draft (S), Issue (Ctrl+↵), Copy from previous invoice, Add line, Save+collect | Issue F (3 competing `confirmNewInvoice` definitions; last wins); stock and balance mutated in browser | `sales` |
| 8 | `invoice-print` | معاينة الطباعة | Lines: #، الصنف، الفئة، الكمية، السعر، الإجمالي | Notes block | Back, WhatsApp (S), PDF/Print (`window.print`) | F (print), S (WhatsApp) | `sales` |
| 9 | `collections` | لوحة التحصيل | رقم الفاتورة، العميل، الاستحقاق، التأخير، المتبقي، الحالة | `modal-payment` | Record payment | P (mapped to `f-receipts` by patch) | `sales`/`finance` |
| 10 | `deliveries` | أذونات صرف وتسليم | رقم الإذن، الطلب، العميل، التاريخ، المصدر، المطلوب، المسلّم، الحالة | — | New delivery | U | `deliveries` |
| 11 | `delivery-create` | إنشاء إذن صرف | Lines: الكود، الصنف، المطلوب، المتاح، الكمية الآن | نوع الإذن*، الطلب*، العميل، المستودع*، التاريخ*، وسيلة النقل، السائق، رقم اللوحة، ملاحظات | Cancel, Save & print (S), Confirm (S) | S→U | `deliveries` |
| 12 | `returns` | مرتجعات المبيعات | رقم المرتجع، الفاتورة، العميل، السبب، نوع المعالجة، المبلغ، الحالة | — | "+ إنشاء مرتجع" (patched: redirects to `invoice-create` in return mode, `__retGo`) | P | `returns` |
| 13 | `return-create` | إنشاء مرتجع | Lines: المنتج، كمية الفاتورة، المرتجعة، السعر، حالة الصنف، الإجمالي | الفاتورة الأصلية*، العميل، التاريخ*، السبب*، نوع المعالجة*، مستودع الاستلام، ملاحظات | Cancel, Confirm (S), Add line | Screen bypassed by patch | `returns` |
| 14 | `products` | المنتجات والأصناف | الكود، الاسم، الفئة، الإجمالي، محجوز، الباقي، سعر البيع، الحالة | `modal-add-product` | Export, Add product | F (local) | `inventory` |
| 15 | `inventory-summary` | ملخص المخزون | (cards, no `<table>`) | — | Export, "تسوية مخزون" (opens confirm dlg) | P | `inventory` |
| 16 | `movements` | حركات المخزون | التاريخ، النوع، المنتج، المستودع، الكمية، المرجع، المستخدم | — | Export | F (in-memory `MOVES`) | `inventory` |
| 17 | `adjustments` | تسويات المخزون | List: رقم، المستودع، التاريخ، السبب، عدد الأصناف، الحالة; lines: المنتج، النظام، الفعلي، الفرق | المستودع*، تاريخ الجرد*، السبب*، تسجيل أثر مالي، قيمة الأثر، الحساب | New, Cancel, Approve (`approveAdjustment`) | P; patched to `stock-add` | `inventory` |
| 18 | `finance` | المالية | 6 tables: customer balances; statement; transfers; expenses; … | COA form (كود*، النوع*، الاسم*، الأب، ملاحظات); transfer (من*، إلى*، المبلغ*، التاريخ*); financial adjustment (النوع*، المبلغ*، التاريخ*، الحساب*، السبب*، المرجع) | `finGo()` sub-pages, new transaction, transfer, expense, adjustment | Superseded at runtime by `fin-overview` + `f-*` screens | `finance` |
| 19 | `containers` | متابعة الحاويات | رقم، المورد، المنشأ، المتوقع، المصروفات، الحالة | `openContainerModal` | Add container | F (local `CONTS`) | `containers` |
| 20 | `container-receive` | استلام حاوية | Items: المنتج، المتوقع، الفعلي، الفرق، سبب الفرق; costs: البند، المبلغ; allocation: الصنف، الكمية، تكلفة الشراء، نصيبه من المصاريف، التكلفة الفعلية | — | Back, Compute landed cost, View stock, Confirm receipt (2 competing `confirmContainerReceipt`) | P | `containers` |
| 21 | `landed-cost` | التكلفة الفعلية | المنتج، الكمية، القيمة %، التكلفة الفعلية/وحدة | — | Back | P (allocation by value — D3 open) | `containers` |
| 22 | `reports` | مركز التقارير | (cards) | — | — | U | `reports` |
| 23 | `reports-sales` | تقرير المبيعات | الموظف، الطلبات، المبيعات، الخصومات، الصافي، الحصة % | — | — | U | `reports` |
| 24 | `reports-profit` | الأرباح والخسائر | البند، الشهر الحالي، السابق، الفرق | — | — | P; COGS fallback `price*0.8` | `reports` |
| 25 | `users` | المستخدم والصلاحيات | — | الاسم، البريد، الهاتف، الدور، كلمة المرور الحالية/الجديدة, password policy (min length, expiry, lockout attempts/minutes, upper/lower, digits, symbols), session timeout & warning | Save (S) | S (UI only) | `admin` |
| 26 | `warehouses` | المخازن | الاسم، الموقع، المسؤول، عدد الأصناف، الإشغال، الحالة | `modal-add-warehouse` | Add | F (local) | `inventory` |
| 27 | `reports-inventory` | تقرير المخزون | المنتج، المستودع، الرصيد، متوسط التكلفة، القيمة، الحالة | — | — | P | `reports` |
| 28 | `reports-financial` | التقارير المالية | (cards) | — | — | U | `reports` |
| 29 | `settings` | الإعدادات العامة | Attachments: الملف، النوع، الحجم، التاريخ | Company: الاسم*، الرقم الضريبي، السجل التجاري، الهاتف، البريد، العنوان، الشعار; numbering prefixes (invoice/order/delivery); VAT default; payment terms; default currency; fiscal-year start; language; time zone; date format | Backup now (S), Restore (confirm dlg), Save (S) | S; patch maps `settings`→`users` | `admin` |

Global dialogs in the markup: `modal-add-customer` (3 tabs), `modal-payment`, `modal-expense`, `modal-add-product`, `modal-add-warehouse`, `modal-confirm`. Patches add programmatic dialogs via `dlg()` (fixed overlay) and `prompt()` password gates.

## 2. Screens added at runtime by patches (39)

Verified present in the DOM after load; contents and behavior are **U** until characterized.

| Group | Ids | Likely target |
|---|---|---|
| Customers | `govs` (governorates), `cust-file`, `inv-detail`, `liq` (customer settlement) | `customers`, `sales` |
| Inventory | `stock-add`, `stock-ret`, `move-detail`, `wh-returns` | `inventory` |
| Finance | `fin-overview`, `f-receipts`, `f-otherinc`, `f-payments`, `f-expenses`, `f-transfers`, `f-treasury`, `f-custbal`, `f-supbal`, `f-finret`, `f-coa`, `f-journal`, `f-ledger`, `f-trial`, `f-reports`, `f-stmt`, `transfers`, `fin2` | `finance` |
| Advanced finance | `x-budget`, `x-recur`, `x-compare`, `x-cash` | `finance` (extras) |
| Advanced inventory/containers | `x-track`, `x-low`, `x-count`, `x-bar`, `x-price`, `cont-money` | `inventory`, `containers` |
| Data/admin | `x-import`, `x-daily`, `x-app`, `x-priv` (private notes), `drivers`, `trash`, `log` | `admin` |

Legacy aliases seen in code (`LEG`): `collections→f-receipts`, `customer-accounts→f-custbal`, `cashiers→f-treasury`, `transfers→f-transfers`, `expenses→f-expenses`, `coa→f-coa`, `reports-financial→f-reports`, `finance→fin-overview`, `installers→drivers`, `adjustments→stock-add`, `return-create→returns`.

## 3. Navigation (runtime sidebar, verified)

| Group | Items |
|---|---|
| الفواتير | كل الفواتير (badge), إنشاء فاتورة, إنشاء مرتجع, المرتجعات |
| العملاء | كل العملاء, إضافة عميل, المحافظات, تصفية العميل |
| المخزون | المنتجات, المخازن, ملخص المخزون, حركة المخزون, إضافة إلى المخزون, المخزون المرتجع |
| المالية | الصندوق الوارد, السحب, المصروفات, الحركات, الشركاء, دفعات الشركاء, فواتير الشراء (via `finOpen(...)`) |
| مرتجع المخازن | single item |
| الحاويات | كل الحاويات |
| التقارير | مركز التقارير, المبيعات, الأرباح, المخزون |
| الإدارة | المستخدمون والصلاحيات, سائق شركة الشحن, سلة المحذوفات, سجل العمليات, لوحة التحكم (**duplicates appear**) |
| الرئيسية | لوحة التحكم |
| مالية متقدمة | ميزانية المصروفات, مصروفات متكررة, مقارنة شهر بشهر, توقع السيولة |
| مخزون وحاويات متقدم | تتبع الحاويات, حد أدنى, الجرد الدوري, باركود, سجل أسعار الشراء |
| البيانات | استيراد من إكسل, الملخص اليومي, تثبيت كتطبيق |

Observations: the runtime sidebar **hides** the static items "Landed Cost", "استلام حاوية", reports-financial, and settings from navigation (still reachable by code); the Admin group contains duplicated entries; `finOpen('home'|'inbox'|'accts'|'exp'|'led'|'part'|'inst'|'purch')` is a separate navigation scheme from `showSection`. Topbar: breadcrumb, global search (Ctrl+K), notifications panel, settings icon (no handler), avatar menu (profile → settings, logout).

## 4. Cross-screen workflows

| Workflow | Path in MVP | Notes |
|---|---|---|
| Invoice → payment | `invoice-create` (collect-now) → writes invoice + cash entry locally | Target: invoice post then separate receipt with allocation |
| Return | `returns` / "إنشاء مرتجع" → `invoice-create` with `isReturn` | Not a separate document today |
| Order → reserve → deliver → invoice | `order-create` → `order-detail` → `delivery-create` / `invoice-create` | Largely S; decision D8 |
| Container receive → landed cost → stock | `containers` → `container-receive` → `landed-cost` → `products` | Duplicate handlers; D2/D3 open |
| Stock adjustment | `inventory-summary` → confirm dlg → `adjustments`/`stock-add` | Direct quantity write |
| Customer → file → invoice detail | `customers` → `cust-file` → `inv-detail` | Dynamic screens |

## 5. Shared interaction patterns

| Pattern | MVP implementation | Port target |
|---|---|---|
| Export CSV | `exportTableCSV(btn)` (Blob) | `DataTable` toolbar action |
| Global search | `runGlobalSearch(q)` over local data | `features/search` → server search endpoint |
| Row menu | `openRowMenu(event, items)` | `RowMenu` |
| Toasts | `showToast(type,title,msg)` | `Toast` |
| Confirm | `modal-confirm`, `confirm()` | `ConfirmDialog` |
| Password gate | `prompt()` for customers, balances, edit | Replaced by server permission + re-auth dialog (needs decision) |
| Bulk actions | `bulkAction('print'|'pdf'|'whatsapp')` | Bulk bar in `DataTable` |
| Notifications | `toggleNotif`, panel | `NotificationPanel` (data source unknown) |
| Keyboard | Ctrl+K, Ctrl+Enter, Esc, Enter/Space on nav | `useHotkey` |
| Themes | `ps-theme` | `ThemeProvider` |

## 6. Features visible in the MVP but absent from the blueprint

`govs` (governorates), `liq` (customer settlement), partners and partner installments, purchase invoices, supplier balances (`f-supbal`), inbox/withdrawals finance flows, warehouse returns, trash (soft delete UI), drivers (shipping-company driver), private notes (`x-priv`), Excel import, daily summary, PWA install, budget/recurring/compare/cash-forecast. These are **in the MVP, so they are in scope for UI parity unless you exclude them** (Decision F-06).
