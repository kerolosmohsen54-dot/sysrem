# Frontend Route Map

Principles: URLs replace `showSection(id)`. Permission names are **proposed** and must be aligned with the backend RBAC. Where the MVP only offers coarse roles (1/2/3 + driver), finer permissions are my proposal.

Legend: **Auth** = requires login. **Perm** = proposed permission. **Cond** = depends on a pending decision.

## Public
| Route | Page | Notes |
|---|---|---|
| `/login` | LoginPage | MVP: phone-number-only field. Proposed: username/phone + password (D: F-03) |
| `/403`, `/404`, `*` | Error pages | |

## Authenticated shell (`/`) — all under `AppShell`
| Route | MVP id | Perm | Page |
|---|---|---|---|
| `/` → redirect `/dashboard` | `dashboard` | `dashboard.read` | DashboardPage |
| `/customers` | `customers` | `customers.read` | CustomerListPage (+ drawer/dialog for add/edit) |
| `/customers/:id` | `cust-file` | `customers.read` | CustomerFilePage (tabs: summary, invoices, payments, statement) |
| `/customers/:id/statement` | `f-stmt` | `customers.statement.read` | CustomerStatementPage |
| `/customers/balances` | `customer-accounts`/`f-custbal` | `customers.balance.read` (MVP gates with a password) | CustomerBalancesPage |
| `/customers/settlement` | `liq` | `finance.settlement.write` | CustomerSettlementPage |
| `/customers/governorates` | `govs` | `reference.read` | GovernoratesPage |
| `/sales/invoices` | `invoices` | `invoices.read` | InvoiceListPage |
| `/sales/invoices/new` | `invoice-create` | `invoices.create` | InvoiceCreatePage |
| `/sales/invoices/new?mode=return` | return mode of `invoice-create` | `returns.create` | same page, return mode — **or** dedicated route per D-F04 |
| `/sales/invoices/:id` | `inv-detail` | `invoices.read` | InvoiceDetailPage |
| `/sales/invoices/:id/print` | `invoice-print` | `invoices.read` | InvoicePrintPage |
| `/sales/collections` | `collections` | `receipts.read` | CollectionsBoardPage |
| `/returns` | `returns` | `returns.read` | ReturnListPage |
| `/returns/new` | `return-create` | `returns.create` | ReturnCreatePage |
| `/orders` (Cond D8) | `orders` | `orders.read` | OrderListPage |
| `/orders/new` (Cond D8) | `order-create` | `orders.create` | OrderCreatePage |
| `/orders/:id` (Cond D8) | `order-detail` | `orders.read` | OrderDetailPage |
| `/deliveries` (Cond D8) | `deliveries` | `deliveries.read` | DeliveryListPage |
| `/deliveries/new` (Cond D8) | `delivery-create` | `deliveries.create` | DeliveryCreatePage |
| `/inventory/products` | `products` | `products.read` | ProductListPage |
| `/inventory/warehouses` | `warehouses` | `locations.read` | WarehouseListPage |
| `/inventory/summary` | `inventory-summary` | `inventory.read` | InventorySummaryPage |
| `/inventory/movements` | `movements` | `inventory.movements.read` | MovementListPage |
| `/inventory/movements/:id` | `move-detail` | same | MovementDetailPage |
| `/inventory/stock-in` | `stock-add` | `inventory.adjust` | StockInPage |
| `/inventory/returned-stock` | `stock-ret` | `inventory.read` | ReturnedStockPage |
| `/inventory/adjustments` | `adjustments` | `inventory.adjust` | AdjustmentListPage / form |
| `/inventory/min-stock` | `x-low` | `inventory.read` | MinStockPage |
| `/inventory/count` | `x-count` | `inventory.adjust` | PeriodicCountPage |
| `/inventory/barcodes` | `x-bar` | `products.read` | BarcodePage |
| `/inventory/purchase-prices` | `x-price` | `products.cost.read` | PurchasePriceHistoryPage |
| `/inventory/warehouse-returns` | `wh-returns` | `inventory.read` | WarehouseReturnsPage |
| `/finance` | `fin-overview`/`finance` | `finance.read` | FinanceOverviewPage |
| `/finance/inbox` | `finOpen('inbox')`/`f-receipts` | `receipts.read` | ReceiptsPage |
| `/finance/withdrawals` | `finOpen('accts')`/`f-payments` | `payments.read` | PaymentsPage |
| `/finance/expenses` | `f-expenses` | `expenses.read` | ExpensesPage |
| `/finance/ledger` | `f-ledger` | `finance.ledger.read` | LedgerPage |
| `/finance/treasury` | `f-treasury` | `treasury.read` | TreasuryAccountsPage |
| `/finance/transfers` | `f-transfers` | `treasury.transfer` | TransfersPage |
| `/finance/other-income` | `f-otherinc` | `finance.read` | OtherIncomePage |
| `/finance/supplier-balances` | `f-supbal` | `suppliers.balance.read` (Cond D9) | SupplierBalancesPage |
| `/finance/finance-returns` | `f-finret` | `finance.read` | FinanceReturnsPage |
| `/finance/coa` | `f-coa` | `accounting.read` | ChartOfAccountsPage |
| `/finance/journal` | `f-journal` | `accounting.read` | JournalPage |
| `/finance/trial-balance` | `f-trial` | `accounting.read` | TrialBalancePage |
| `/finance/adjustments` | `financial-adjustments` | `finance.adjust` (MVP: ROLE≥3) | FinancialAdjustmentsPage |
| `/finance/currencies` | `currencies` | `settings.currency` (MVP: ROLE≥3) | CurrenciesPage |
| `/finance/partners` | `finOpen('part')` | `partners.read` (Cond D7) | PartnersPage |
| `/finance/partner-installments` | `finOpen('inst')` | `partners.read` (Cond D7) | PartnerInstallmentsPage |
| `/finance/purchase-invoices` | `finOpen('purch')` | `purchases.read` (Cond D9) | PurchaseInvoicesPage |
| `/finance/budget`, `/recurring`, `/compare`, `/cash-forecast` | `x-budget`, `x-recur`, `x-compare`, `x-cash` | `finance.analytics.read` | extras (Cond F-06) |
| `/containers` | `containers` | `containers.read` | ContainerListPage |
| `/containers/:id/receive` | `container-receive` | `containers.receive` | ContainerReceivePage |
| `/containers/:id/landed-cost` | `landed-cost` | `containers.read` | LandedCostPage |
| `/containers/:id/money` | `cont-money` | `containers.costs.read` | ContainerCostsPage |
| `/containers/tracking` | `x-track` | `containers.read` | ContainerTrackingPage |
| `/reports` | `reports` | `reports.read` | ReportHubPage |
| `/reports/sales` | `reports-sales` | `reports.sales` | SalesReportPage |
| `/reports/profit` | `reports-profit` | `reports.profit` (Cond D6) | ProfitReportPage |
| `/reports/inventory` | `reports-inventory` | `reports.inventory` | InventoryReportPage |
| `/reports/financial` | `reports-financial`/`f-reports` | `reports.financial` | FinancialReportsPage |
| `/admin/users` | `users` | `users.manage` | UsersPage |
| `/admin/settings` | `settings` | `settings.manage` | SettingsPage (company, numbering, tax, locale, backup) |
| `/admin/audit-log` | `log` | `audit.read` | AuditLogPage |
| `/admin/trash` | `trash` | `trash.manage` | TrashPage |
| `/admin/drivers` | `drivers` | `drivers.read` (Cond D7) | DriversPage |
| `/admin/import` | `x-import` | `import.run` | ImportPage |
| `/me/notes` | `x-priv` | `self` | PrivateNotesPage |
| `/daily-summary` | `x-daily` | `reports.read` | DailySummaryPage |

Global overlays (not routes): global search (Ctrl+K), notifications panel, add-customer dialog (reachable from invoice/order forms), payment dialog, expense dialog, confirm dialog.

## Route guard behavior
1. No session → redirect to `/login?next=…`.
2. Session but missing permission → render 403 panel inside the shell (not a silent redirect).
3. Legacy aliases kept as redirects so bookmarks/habits survive: see `LEG` list in the inventory (e.g., `/customer-accounts` → `/customers/balances`).
4. The driver restriction in the MVP (`DRV_OK`: invoices, invoice-create, invoice-print, inv-detail, customers, customer-accounts, cust-file) becomes a permission set on a driver role, **enforced by the API**.

## Per-route side effects found in the MVP wrappers (must be preserved or consciously dropped)
- Customers / balances: password prompt (`custOK`, `pw()`).
- `invoice-create`: runs `fill()`, `initInvoiceForm`.
- `returns`: runs `renderRets()`, `newReturn()`.
- `settings`/`users`: `user-tabs` visibility.
- `dashboard`: `dashOD()` overdue widgets.
- Finance routes: `finRen…` renderers on entry.
- Breadcrumb names from `NAMES` map.
