# Precision Slate ERP — Frontend Architecture

Status: **Proposal for approval.** Phase: analysis and documentation only. No application code has been written.
Date: 2026-10-09

## 1. Evidence base

| Artifact | Status | Notes |
|---|---|---|
| `precision-slate-erp-v43.html` (821,223 bytes, 6,383 lines) | **Inspected** (static analysis + headless-browser run) | Single-file MVP, RTL Arabic. |
| `Precision_Slate_ERP_Blueprint_AR.pdf` | **Inspected** | Arabic blueprint. Its inventory numbers were cross-checked against the HTML (see §2). Its backend/DB sections are *proposals*, not facts. |
| Frontend task brief (English) | **Inspected** | Defines scope and the 10 deliverables. |
| Approved database schema + docs | **Missing** | Only the blueprint's proposed table list exists. Not an approved schema. |
| UI/UX design files / screenshots | **Missing** | The MVP itself is the only visual reference. |
| `manifest.webmanifest`, `icon-192.png` | **Missing** | Referenced by `<link>` tags but not supplied. |
| Backend API contract / OpenAPI | **Missing** | Nothing verified. |
| Requirements / business-rules docs | **Missing** | Only the blueprint's pending decisions D1–D10. |

No workspace tree beyond the two uploads exists, so there was nothing else to search recursively.

## 2. Verified facts about the MVP

Cross-check against the blueprint's numbers:

| Metric | Blueprint | Measured | Result |
|---|---|---|---|
| File size / lines | ~821 KB / 6,383 | 821,223 B / 6,383 | Match |
| Static `sec-*` screens | 29 | 29 | Match |
| `<script>` blocks | 18 | 18 | Match |
| `<style>` blocks | 11 | 10 lines contain `<style` | **Mismatch by 1 — re-count needed** |
| Unique named functions | 332 | 332 (375 definitions) | Match; **32 names are defined more than once** |
| `fetch` / `XMLHttpRequest` | none | none | Match — there is **no backend call anywhere** |

Additional measurements (mine, not in the blueprint):

- **68 screens exist at runtime** (`.section-content` elements after load): 29 static + 39 created by JS patches (`mk('…')`, `createElement`). Screens such as `fin-overview`, `f-receipts`, `f-journal`, `f-trial`, `x-budget`, `x-cash`, `govs`, `stock-ret`, `trash`, `log`, `drivers` are **not in the static HTML**.
- **Sidebar differs from the static markup.** Later patches (`nav()` redefined 4×, `showSection` wrapped 20+ times) rebuild it. Runtime groups: Invoices, Customers, Inventory, Finance, Warehouse returns, Containers, Reports, Admin, Home, Advanced finance, Advanced inventory/containers, Data.
- **Login at runtime is phone-number only** (`#login-pass` placeholder "اكتب رقم تليفونك", user select hidden). Hard-coded `1234` exists as customer-section password (`ps-cust-pw`), edit password hash seed (`ps-edit-pw-h`), and an admin override (v45 patch near line 6360).
- 515 inline `onclick=` attributes; 234 `innerHTML` assignments (XSS-relevant); 17 buttons whose entire handler is `showToast('success', …)` (cosmetic only).
- Hard-coded estimates: COGS fallback `cost || price*0.8` (lines ~4304, 4322).
- Currency: `ج.م` appears 110 times, `EGP` once. Tax: a "15%" label exists in order-detail but invoice flow is described as untaxed. **D1 is unresolved.**
- State lives in `localStorage` (keys such as `ps-erp-v4`, `ps-fin2`, `ps-expenses`, `ps-settings`, `ps-role`, `ps-wret`, `ps-theme`) plus in-memory globals (`DB`, `INV_CATALOG`, `MOVES`, `CONTS`, `COLS`, `SEQ`).
- Roles in code: numeric `ROLE` 1/2/3 (`ALLOW={1:['fin-overview','f-receipts'],2:'*',3:'*'}`), plus a "driver" restriction (`DRV_OK`). Navigation-level only.

**Limit of this analysis:** behavior classification is from reading code plus one headless load. I did not click every control; items marked "unverified" in the inventory need a scripted walkthrough.

## 3. Constraint conflict to resolve first

The brief says the backend will be a **PHP REST API (MySQL/MariaDB)**. The blueprint proposes **Node/Express + PostgreSQL**. The frontend must not depend on either. Therefore:

- The API layer is isolated behind typed service modules and an OpenAPI-generated client, so the backend language is irrelevant.
- Money and quantities are transported as **decimal strings**, not JS numbers (works identically for MySQL `DECIMAL` and PostgreSQL `NUMERIC`).
- Cookie vs bearer auth is deferred to the Backend Architecture (Decision F-02).

## 4. Technology recommendation

| Concern | Choice | Why (tied to evidence) |
|---|---|---|
| Language | **TypeScript** | 68 screens and money/quantity logic; the MVP's 32 duplicate function names and patch-over-patch overrides are exactly the class of bug types prevent. |
| UI library | **React 18** | Justified, not fashionable: ~68 screens share the same few patterns (page header, stat cards, filterable table, modal form, status badge). Today these are re-implemented as string templates (`tb()`, `page()`, `card()`, `dlg()` helpers, redefined up to 6×). Components replace them. Vanilla JS would reproduce the same duplication. |
| Build | **Vite** | Fast, static output deployable beside a PHP API (plain `dist/` served by Apache/Nginx). No Node server is required in production. |
| Routing | **React Router (data router)** | Replaces `showSection(id)` and its 20 wrappers with real URLs, deep links, and route guards. |
| Server state | **TanStack Query** | Caching, invalidation after posting invoices/receipts, retry rules. Replaces localStorage as source of truth. |
| Client state | **Zustand** (tiny; session/UI only) | Needed only for: current user/permissions snapshot, sidebar open state, theme, invoice-draft form scratch. Anything business-related stays in the server. |
| Forms | **React Hook Form + Zod** | The invoice, return, order, adjustment, container-receipt forms are the most complex surfaces; Zod schemas double as documentation of validation rules. |
| Tables | **Own `DataTable` over TanStack Table core** | The MVP's tables share one visual style (`.table-wrap`); we need server-side sort/filter/pagination, row menus, bulk select (invoices have bulk print/PDF/WhatsApp). |
| Styling | **Plain CSS with CSS variables (ported verbatim tokens) + CSS Modules** | Preserves the existing look exactly. No Tailwind/UI kit: adopting one risks silent redesign, which the brief forbids. |
| Money | **`decimal.js`-style string math only for display/preview** | Server is authoritative; client preview must not be the source of financial truth. |
| i18n/RTL | Single Arabic locale file now; `dir="rtl"` at root; logical CSS properties | Only Arabic is evidenced. Settings screen offers a language selector, but no other language content exists (gap). |
| Testing | **Vitest + React Testing Library + MSW + Playwright** (+ axe for a11y) | See test strategy doc. |
| Lint/format | ESLint (typescript-eslint, jsx-a11y, `no-restricted-syntax` for `dangerouslySetInnerHTML`), Prettier | Directly addresses 234 `innerHTML` uses. |

**Rejected options:** Next.js/SSR (no SEO need, authenticated app, PHP backend); Redux Toolkit (server state dominates); Tailwind/MUI/Ant (visual drift risk); micro-frontends (single team, one product); keeping vanilla JS (see above).

## 5. Layering rules

```
Route page → Feature container → Feature hooks (queries/mutations) → Feature api service → shared API client → HTTP
                   ↓
            Shared UI components (no data fetching, no business rules)
```

1. `shared/ui` never imports from `features/*`.
2. Features import from `shared/*` and from other features only through their `index.ts` public surface.
3. Only `*/api/*.ts` files call the HTTP client. Components never call `fetch`.
4. Business-facing frontend logic (draft totals preview, return-quantity limits, status-to-badge mapping) lives in `features/<x>/model/` as pure functions with unit tests. It is explicitly **advisory**; the server recomputes and rejects.
5. No SQL, no DB credentials, no secrets in the bundle. Only `VITE_API_BASE_URL` is configurable.
6. No `localStorage` for business data. Allowed: theme, sidebar state, last-used filters (non-sensitive).

## 6. Cross-cutting design

**Auth.** Session established via `POST /auth/login`; the frontend keeps `currentUser` + `permissions[]` returned by `GET /auth/me`. Route guards read permissions; **hiding menu items is UX only** — every 403 from the API is handled centrally. Replaces `ROLE`, `can()`, `ALLOW`, `DRV_OK`, and all `prompt()`-based password gates.

**Permission-aware navigation.** One typed `navigation.config.ts` lists groups/items with `requiredPermission`. Sidebar and router are generated from it, ending the 4 competing `nav()` rewrites.

**Error handling.** One `ApiError` type (status, code, message, field errors, requestId). Mapping: 401 → login redirect; 403 → "not authorized" panel; 404 → not-found; 409/422 → inline business-rule message; 400 with field errors → mapped into form fields; network/5xx → retry banner + Request-ID shown for support. Error boundary per route.

**Loading/empty/error/success/confirm states.** Reuse the MVP conventions: empty table row text ("لا توجد بيانات"), toasts (`showToast(type,title,msg)`), `modal-confirm` for destructive actions. Skeleton rows for loading (new, minimal; flagged as an addition in the gaps doc).

**Idempotency.** Mutations that post financial/stock documents attach an `Idempotency-Key` generated once per form-open, so double-clicks and retries cannot double-post. (Contract to be confirmed by the backend.)

**Printing/export.** Invoice print preview keeps the existing print CSS (`@media print`), implemented as a dedicated print route/component. CSV export becomes server-driven for large sets, client-side only for the visible page. PDF/WhatsApp bulk actions are currently stubs (see inventory).

**Accessibility.** MVP baseline: v43 added keyboard focus + Enter/Space on nav. Target: all interactive elements are real `<button>`/`<a>`; dialogs trap focus and close on Esc (the MVP has Esc for the row menu only); form labels bound to inputs; contrast checked against the existing dark tokens; `Ctrl+K` global search and `Ctrl+Enter` invoice submit retained.

**Responsive.** Breakpoints taken from the MVP: 1100px, 768px, 600px, plus print. A mobile sidebar toggle was added in v42 and is preserved.

**Theme.** `ps-theme` exists; dark is default. Light theme tokens are not verified (gap).

## 7. Design tokens to preserve (from `:root`)

`--bg #111415`, `--surface-low #191c1d`, `--surface #1d2021`, `--surface-high #272a2b`, `--surface-highest #323536`, `--surface-bright #3a3d3e`, `--border #414752`, `--border-strong #5c6370`, `--text #e1e3e4`, `--text-secondary rgba(255,255,255,.60)`, `--text-dim rgba(255,255,255,.38)`, `--accent #4a9eff`, `--success #3ecf8e`, `--warning #f5a623`, `--danger #e05252`, `--info #9b8ef7` (each with a `-dim` 15% variant), `--topbar-h 52px`, `--radius 4px`, `--radius-lg 8px`, `--sidebar-w 240px` (later overridden to **196px** by a patch at line ~5819 — **which width is canonical needs your confirmation**). Base `html{font-size:13px; direction:rtl}`; font **IBM Plex Sans Arabic** 300–700 via Google Fonts (self-host recommended); `font-variant-numeric: tabular-nums`.

## 8. Migration hazards found in the MVP

1. 32 function names defined more than once (e.g., `confirmNewInvoice` ×3, `confirmContainerReceipt` ×2, `printInvoice` ×2, `addMovement` ×2): the **last definition wins**; earlier ones are dead or partially active. The port must follow the *effective* behavior, which needs a scripted run per workflow before each module is built.
2. `showSection` wrapped 20+ times, each adding side effects (password gates, renderers, role checks, breadcrumb names). These side effects must be cataloged per route (see route map).
3. Business logic and rendering are interleaved in string templates; no pure functions to lift out.
4. Inline `onclick` and global state prevent unit testing without refactoring.
5. Several workflows rely on timing hacks (e.g., return flow detected via `click`/`setTimeout` per the blueprint's gap list; `__retGo` flag).
6. Seed/wipe flags (`ps-v17-seed`, `ps-v18-seed`, `ps-v32-wiped`) show the data model changed across versions; any legacy-import tool must tolerate multiple shapes.
