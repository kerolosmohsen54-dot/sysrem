# Frontend API Integration Contract (PROPOSED)

**Nothing in this document is a verified endpoint.** No backend contract was supplied. The endpoints below come from two sources only: (a) the blueprint's *proposed* API table (marked **BP**), and (b) endpoints the frontend needs to reproduce MVP screens but that the blueprint does not list (marked **NEW**). All must be confirmed by the Backend Architecture. The brief names a **PHP REST API**; the blueprint assumed Node/Express. The frontend contract below is language-neutral.

## 1. Transport conventions (proposed)
| Topic | Proposal |
|---|---|
| Base URL | `VITE_API_BASE_URL` (e.g., `/api/v1`) |
| Format | JSON, UTF-8, Arabic strings |
| Auth | Cookie session (HttpOnly, SameSite) + CSRF token **or** short-lived bearer; **decision F-02**. Frontend never stores tokens in `localStorage`. |
| Request tracing | `X-Request-Id` header sent by client; echoed in errors |
| Idempotency | `Idempotency-Key` header on every posting mutation |
| Lists | `?page=&limit=&q=&sort=&from=&to=&status=` → `{ data: T[], page, limit, total }` |
| Money / quantities | **decimal strings** (`"1250.50"`, `"3.000"`), never JSON numbers |
| Dates | ISO-8601; server owns timestamps |
| Errors | `{ error: { code, message, fields?: {name: msg}, requestId } }` |
| Status codes the UI handles | 400 field errors, 401 re-login, 403 forbidden, 404, 409 conflict/duplicate, 422 business-rule violation, 5xx |

## 2. Endpoint needs by feature
Columns: Source = BP / NEW. "Loading" = how the UI behaves while waiting.

### auth
| Operation | Proposed endpoint | Src | Request → Response | UI behavior | Authz |
|---|---|---|---|---|---|
| Login | `POST /auth/login` | BP | `{identifier, password}` → user + permissions | button spinner; 401 inline message; lockout/429 message | public |
| Session bootstrap | `GET /auth/me` | NEW | → `{id,name,role,permissions[]}` | app splash until resolved | any |
| Logout | `POST /auth/logout` | NEW | — | redirect | any |
| Change password | `POST /auth/change-password` | NEW | `{current,new}` | field errors against policy | self |

### customers
| Operation | Endpoint | Src |
|---|---|---|
| List/search | `GET /customers?q=&status=` | BP |
| Create / update | `POST /customers`, `PATCH /customers/:id` | BP |
| Detail with recent orders, invoices, payments | `GET /customers/:id` | NEW |
| Statement | `GET /customers/:id/statement?from=&to=` | BP |
| Balances list | `GET /customers/balances` | NEW |
| Attachments | `POST /customers/:id/attachments` (multipart) | NEW — blueprint says JSON only; file storage undecided |
| Governorates | `GET /reference/governorates` | NEW |

### sales / returns
| Operation | Endpoint | Src |
|---|---|---|
| List invoices | `GET /sales/invoices` | NEW (list not in BP) |
| Create draft | `POST /sales/invoices` | BP |
| Post | `POST /sales/invoices/:id/post` | BP |
| Reverse (reason required) | `POST /sales/invoices/:id/reverse` | BP |
| Create return | `POST /sales/invoices/:id/returns` | BP |
| Returnable quantities | `GET /sales/invoices/:id/returnable` | NEW |
| Receipt (collection) + allocations | `POST /receipts` | BP |
| Open invoices for collections board | `GET /sales/collections` | NEW |
| Print data | `GET /sales/invoices/:id` (same payload) | NEW |
| Bulk PDF / WhatsApp | undefined | NEW — **MVP stubs; need decision** |

UI rules tied to MVP: item search by name/code/barcode → `GET /products?q=`; credit-limit banner needs `creditLimit` and `balance` from the customer payload; the invoice number is "auto" in the MVP → **server-assigned**, shown after save, never generated in the browser; client-side line/total calculation is a **preview only**.

### inventory
| Operation | Endpoint | Src |
|---|---|---|
| Products CRUD + list with stock/reserved | `GET/POST/PATCH /products` | NEW |
| Locations (warehouses) CRUD | `GET/POST/PATCH /locations` | NEW |
| Stock balances | `GET /inventory/balance` | BP |
| Movements list | `GET /inventory/movements` | NEW |
| Transfer | `POST /inventory/transfers` | BP |
| Adjustment (reason required) | `POST /inventory/adjustments` | NEW |
| Stock-in | `POST /inventory/receipts` | NEW |
| Damaged→sellable | `POST /inventory/damaged/:id/restore` | BP |
| Min-stock, count sheet, barcode, purchase price history | `GET`s | NEW |

### finance
| Operation | Endpoint | Src |
|---|---|---|
| Treasury accounts | `GET/POST /finance/treasury-accounts` | NEW |
| Expense | `POST /finance/expenses` | BP |
| Transfer between accounts | `POST /finance/transfers` | BP |
| Void entry | `POST /finance/entries/:id/void` | BP |
| Ledger / journal / trial balance / COA | `GET /finance/ledger|journal|trial-balance|coa` | NEW |
| Financial adjustments, currencies | `…` | NEW |
| Partners, installments, purchase invoices, supplier balances | `…` | NEW — blocked on D7, D9 |

### containers
| Operation | Endpoint | Src |
|---|---|---|
| Create / list | `POST/GET /containers` | BP / NEW |
| Add cost | `POST /containers/:id/costs` | BP |
| Receive (once) | `POST /containers/:id/receive` | BP |
| Landed-cost preview | `GET /containers/:id/landed-cost` | NEW |

### reports / admin
| Operation | Endpoint | Src |
|---|---|---|
| Reports | `GET /reports/{sales,profit,inventory,cashflow}` | BP |
| Audit log | `GET /admin/audit` | BP |
| Users, roles, permissions | `GET/POST/PATCH /admin/users`, `/admin/roles` | NEW |
| Settings (company, numbering, tax, locale) | `GET/PUT /admin/settings` | NEW |
| Backup / restore | undefined | NEW — probably an ops function, not a browser button |
| Excel import | `POST /admin/import` | NEW |
| Global search | `GET /search?q=` | NEW |
| Dashboard stats | `GET /dashboard` | NEW |
| Trash / restore | `GET /admin/trash`, `POST …/restore` | NEW — blueprint prefers *no* delete for posted docs |
| Markups (price above company price) | `GET /admin/markups` | BP — gated by D6 |

## 3. Frontend service shape
```ts
// features/sales/api/invoices.api.ts  (illustrative, not final)
export const invoicesApi = {
  list: (p: InvoiceListParams) => http.get<Paged<InvoiceSummary>>('/sales/invoices', { params: p }),
  createDraft: (b: InvoiceDraftInput) => http.post<InvoiceDraft>('/sales/invoices', b),
  post: (id: string, key: string) => http.post<Invoice>(`/sales/invoices/${id}/post`, undefined, { idempotencyKey: key }),
}
```
Types are hand-written first; once the backend publishes OpenAPI, generate them and delete the hand-written copies.

## 4. Unresolved dependencies
1. Backend stack and auth model (F-01, F-02).
2. Real permission list and role matrix.
3. Whether invoice **post** and **create** are two calls (blueprint) or one for the "issue immediately" UX the MVP has (`إصدار الفاتورة Ctrl+↵`).
4. Whether the MVP's "collect now" creates a separate receipt server-side (blueprint implies yes).
5. Search, dashboard, notifications, and settings endpoints are not in the blueprint.
6. File uploads (customer attachments, company logo, settings attachments) have no storage design.
7. Bulk print/PDF/WhatsApp has no defined integration.
8. Pagination/sorting convention for all lists.
9. Rounding rule (blueprint says half-up per line, unconfirmed) and decimal scales.
10. Currency model: single currency (D1) vs the MVP's per-customer/order currency columns and `currencies` screen.
